﻿namespace DotNetCoreExamplesUsingVSCode;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");
        string ename="Banta Singh";
        Console.WriteLine("Hello {0}, how are you doing?", ename);
        Fun();
    }

    static void Fun(){
        string? ename;
        Console.WriteLine("Enter Your Name");
        ename=Console.ReadLine();

        Console.WriteLine("Hello {0}, how are you doing today",
            ename);
    }
}
