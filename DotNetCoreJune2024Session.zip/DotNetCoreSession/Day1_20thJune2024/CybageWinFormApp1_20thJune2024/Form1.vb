﻿Option Explicit On
Imports System.Runtime.CompilerServices
Imports CybageDemoDotNetFrameworkLibrary

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim myObj As New CybPuneCT1
        Label1.Text = myObj.GreetUser("Jojo Sharma")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim myObj As New CybPuneCT1,
            mynum As Int32, square As Integer

        mynum = Convert.ToInt32(TextBox1.Text)
        square = myObj.CalculateSquare(mynum)

        Label3.Text = "Square of : " +
            mynum.ToString() + " is : " + square.ToString()

    End Sub
End Class
