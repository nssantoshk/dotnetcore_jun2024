﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Configuration;

Console.WriteLine("Hello, World!");


var configurationObject =
    new ConfigurationBuilder().SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile(@"D:\LND\CalendarPrograms_2024_2025\June2024\DotNetCoreSession\ConsoleApp1WithCore_20thJune2024\appsettings.json",
    optional: false, reloadOnChange: true).Build();

Console.WriteLine("Name stored in appsettings.json file is : \t{0}",
    configurationObject["cybagepersonname"]);

