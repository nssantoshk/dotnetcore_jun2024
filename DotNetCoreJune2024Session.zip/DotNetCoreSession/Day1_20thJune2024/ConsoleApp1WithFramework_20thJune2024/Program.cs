﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace ConsoleApp1WithFramework_20thJune2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String cybagepersonname=
                ConfigurationManager.AppSettings["cybagepersonname"].ToString();

            Console.WriteLine("Name of the person working for Cybage is : {0}",
                cybagepersonname);
        }
    }
}
