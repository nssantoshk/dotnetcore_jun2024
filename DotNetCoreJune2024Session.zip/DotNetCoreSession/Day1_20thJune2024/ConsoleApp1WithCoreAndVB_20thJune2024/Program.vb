Imports System

Module Program
    Sub Main(args As String())
        Dim x As Integer
        x = 400
        Console.WriteLine("Hello World!")
        Console.WriteLine(x)

    End Sub
End Module
