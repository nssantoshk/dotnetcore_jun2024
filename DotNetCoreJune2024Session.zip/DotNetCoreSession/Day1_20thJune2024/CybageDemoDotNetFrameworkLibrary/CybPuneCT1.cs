﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageDemoDotNetFrameworkLibrary
{
    public class CybPuneCT1
    {
        public string GreetUser(string username)
        {
            String msg = "Hello " + username + ", how are you doing?";
            return msg;
        }
        public int CalculateSquare(int number)
        {
            return number * number;
        }
    }
}
