﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageDemoDotNetFrameworkLibrary
{
    public class CybageEmp
    {
        public int EmpId { get; set; }
        public String EmpName { get; set; }
        public int EmpAge { get; set; }
    }
}
