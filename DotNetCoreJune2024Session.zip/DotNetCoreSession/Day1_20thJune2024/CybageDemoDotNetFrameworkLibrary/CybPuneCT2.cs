﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CybageDemoDotNetFrameworkLibrary
{
    public class CybPuneCT2
    {
        private List<CybageEmp> empList;
        public CybPuneCT2()
        {
                this.empList = new List<CybageEmp>();
        }
        public bool RegisterNewEmployee(CybageEmp emp)
        {
            this.empList.Add(emp);
            return true;
        }
        public List<CybageEmp> GetEmpList()
        {
            return this.empList;
        }
    }
}
