﻿namespace ConsoleApp2WithCore_20thJune2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            String ename = "Jojo Sharma";
            Console.WriteLine("{0}", ename);

            MyFun();
        }

        static void MyFun()
        {
            String? ename;
            Console.WriteLine("Please enter your name");
            ename = Console.ReadLine();
            Console.WriteLine("{0}", ename);
        }
    }
}
