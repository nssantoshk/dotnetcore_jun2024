﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLifetimesDemo.Services
{
    internal class ScopedService:IScopedService
    {
        private readonly string _guid;

        public ScopedService()
        {
            _guid = Guid.NewGuid().ToString();
        }

        public string GetGuid() => _guid;
    }
}
