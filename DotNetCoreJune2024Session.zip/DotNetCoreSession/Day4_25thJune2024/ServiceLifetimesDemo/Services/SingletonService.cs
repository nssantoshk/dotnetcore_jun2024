﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLifetimesDemo.Services
{
    internal class SingletonService:ISingletonService
    {
        private readonly string _guid;

        public SingletonService()
        {
            _guid = Guid.NewGuid().ToString();
        }

        public string GetGuid() => _guid;
    }
}
