﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using ServiceLifetimesDemo.Services;

namespace ServiceLifetimesDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            var host = CreateHostBuilder(args).Build();

            // Demonstrate the service lifetimes
            DemonstrateServiceLifetimes(host.Services);

            // Wait for user input to close the console
            Console.ReadLine();
        }

        static IHostBuilder CreateHostBuilder(string[] args) =>
        Host.CreateDefaultBuilder(args)
            .ConfigureServices((_, services) =>
                services.AddSingleton<ISingletonService, SingletonService>()
                .AddScoped<IScopedService, ScopedService>()
                .AddTransient<ITransientService, TransientService>());

        #region Commented Code
        //.AddScoped<IScopedService, ScopedService>()
        //.AddSingleton<ISingletonService, SingletonService>());
        #endregion

        static void DemonstrateServiceLifetimes(IServiceProvider services)
        {
            // Create a scope to simulate a request
            using (var scope = services.CreateScope())
            {
                #region Transient
                var transient1 = scope.ServiceProvider.GetRequiredService<ITransientService>();
                var transient2 = scope.ServiceProvider.GetRequiredService<ITransientService>();
                var transient3 = scope.ServiceProvider.GetRequiredService<ITransientService>();
                #endregion

                #region Scoped
                var scoped1 = scope.ServiceProvider.GetRequiredService<IScopedService>();
                var scoped2 = scope.ServiceProvider.GetRequiredService<IScopedService>();

                Console.WriteLine($"Scoped1: {scoped1.GetGuid()}");
                Console.WriteLine($"Scoped2: {scoped2.GetGuid()}\n");

                #endregion

                #region singleton

                var singleton1 = scope.ServiceProvider.GetRequiredService<ISingletonService>();
                var singleton2 = scope.ServiceProvider.GetRequiredService<ISingletonService>();

                Console.WriteLine($"\tSingleton1: {singleton1.GetGuid()}");
                Console.WriteLine($"\tSingleton2: {singleton2.GetGuid()}\n");
                #endregion

                #region Transient Printing Code
                Console.WriteLine($"\t\t\tTransient1: {transient1.GetGuid()}");
                Console.WriteLine($"\t\t\tTransient2: {transient2.GetGuid()}");
                Console.WriteLine($"\t\t\tTransient3: {transient3.GetGuid()}\n");

                transient1 = scope.ServiceProvider.GetRequiredService<ITransientService>();
                Console.WriteLine($"\t\t\tNow the Transient1 for the second time is : {transient1.GetGuid()} \n");
                #endregion

                #region scoped and singletone - printing code
                //Console.WriteLine($"Scoped1: {scoped1.GetGuid()}");
                //Console.WriteLine($"Scoped2: {scoped2.GetGuid()}");

                //Console.WriteLine($"Singleton1: {singleton1.GetGuid()}");
                //Console.WriteLine($"Singleton2: {singleton2.GetGuid()}");
                #endregion
            }

            #region Commented Code
            /// Create another scope to simulate a new request
            using (var scope = services.CreateScope())
            {
                var scoped1 = scope.ServiceProvider.GetRequiredService<IScopedService>();
                var scoped2 = scope.ServiceProvider.GetRequiredService<IScopedService>();

                Console.WriteLine($"New Scoped1: {scoped1.GetGuid()}");
                Console.WriteLine($"New Scoped2: {scoped2.GetGuid()}\n");
            }
            #endregion


            using (var scope = services.CreateScope())
            {
                var singleton1 = scope.ServiceProvider.GetRequiredService<ISingletonService>();
                var singleton2 = scope.ServiceProvider.GetRequiredService<ISingletonService>();

                Console.WriteLine($"\t New Set of Singleton1: {singleton1.GetGuid()}");
                Console.WriteLine($"\t New Set of Singleton2: {singleton2.GetGuid()}");
            }
        
        }
    }
}
