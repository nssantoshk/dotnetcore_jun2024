﻿namespace CybageDotNetCoreLibrary1
{
    public class CybageDemo
    {
        public string? GreetUser()
        {
            String? message = "Hello user, how are you doing?";
            return message;
        }
    }
}
