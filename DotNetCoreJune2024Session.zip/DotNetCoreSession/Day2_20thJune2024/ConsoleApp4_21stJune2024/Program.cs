﻿namespace ConsoleApp4_21stJune2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //SMS smsObject=new SMS();
            //String message = "Hello all, we are learning how to work with .net core";
            //smsObject.Send(message);

            Communication communicationObject = new Communication();
            communicationObject.MessagingObject = new Email();
            communicationObject.Communicate("This is Cybage ");


        }
    }
}
