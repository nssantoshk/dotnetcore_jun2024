﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4_21stJune2024
{
    internal interface IMessaging
    {
        void Send(string message);
    }
}
