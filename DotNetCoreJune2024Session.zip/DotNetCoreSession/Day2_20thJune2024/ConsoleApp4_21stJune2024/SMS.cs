﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4_21stJune2024
{
    internal class SMS : IMessaging
    {
        public void Send(string message)
        {
            Console.WriteLine("{0} - this message was sent via : {1}",
                message, this.GetType().Name);
        }
    }
}
