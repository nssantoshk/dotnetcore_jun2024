﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4_21stJune2024
{
    internal class Communication
    {
        private IMessaging? messagingObject;
        //public Communication()
        //{
        //    //this.messagingObject = msgObject;
        //    //switch (messagingWay)
        //    //{
        //    //    case "SMS":
        //    //        {
        //    //            this.messagingObject = new SMS();
        //    //            break;
        //    //        }
        //    //    case "Email":
        //    //        {
        //    //            this.messagingObject = new Email();
        //    //            break;
        //    //        }
        //    //}
        //}

        public IMessaging MessagingObject
        {
            set
            {
                this.messagingObject = value;
            }
        }
        public void Communicate(string message)
        {
            this.messagingObject.Send(message);
        }
    }
}
