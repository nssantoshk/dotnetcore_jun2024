﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemoWithCore
{
    abstract internal class Person
    {
        protected string? _name, _city;
        protected byte _age;
        public Person(String? name,
            byte age, string? city)
        {
            this._name = name;
            this._age = age;
            this._city = city;
        }
        public string? DisplayPersonDetails()
        {
            String? personInfo =
                "Name is : \t" + this._name +
                "\tAge is : \t" + this._age +
                "\tCity Name is : \t" + this._city;

            return personInfo;
        }

        public abstract void IncreaseAge(byte incrementalValue);


    }
}
