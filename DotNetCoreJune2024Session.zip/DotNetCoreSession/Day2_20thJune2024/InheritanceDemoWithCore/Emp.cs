﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemoWithCore
{
    internal class Emp:Person
    {
        public Emp(String? empname,
            byte empage, string? empcity,
            string? empdesign,
            int empsalary):base(empname, empage, empcity)
        {
            
        }

        public override void IncreaseAge(byte incrementalValue)
        {
            this._age=incrementalValue;
        }
    }
}
