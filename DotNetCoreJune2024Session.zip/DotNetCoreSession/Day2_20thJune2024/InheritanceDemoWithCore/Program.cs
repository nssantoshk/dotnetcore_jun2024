﻿namespace InheritanceDemoWithCore
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Emp e1 = new Emp("Jojo",
                23, "Delhi", "Programmer", 5000);

            Person p1 = e1; /// We declared an object called "p1"
                            /// This object is holding reference of "e1" object which is of type "Emp" class
                            /// "p1" object is actually of type "Person" class
                            /// It is able to hold reference of the "e1" object because of inheritance
                            /// "Emp" class is actually of type "Person" - "Is-A" relationship

            p1.IncreaseAge(26);

            Console.WriteLine(p1.DisplayPersonDetails());

            Person p2 = new Emp("Popat Lal", 25, "Sonipat", "Programmer", 5000);

            Console.WriteLine(p2.DisplayPersonDetails());
            p2.IncreaseAge(28);

            Console.WriteLine(p2.DisplayPersonDetails());
        }
    }
}
