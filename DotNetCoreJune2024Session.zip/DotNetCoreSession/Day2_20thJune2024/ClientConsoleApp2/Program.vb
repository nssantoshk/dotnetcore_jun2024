Imports System
Imports CybageDotNetCoreLibrary1

Module Program
    Sub Main(args As String())
        Dim myObj As New CybageDemo
        Console.WriteLine("{0}", myObj.GreetUser())
    End Sub
End Module
