﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3_20thJune2024
{
    abstract internal class Section
    {
        protected String? _sectionName,
            _sectionDescription;
        public Section() { }

        public abstract void AddSectionDetails(
            String sectionName, String sectionDescription );

        public String ShowSectionDetails()
        {
            String sectionInfo =
                "Section Name : \t" + this._sectionName +
                Environment.NewLine + "Section Description : \t" +
                this._sectionDescription;

            return sectionInfo;
        }

        public virtual void UpdateSectionDetails(
            String sectionName, String sectionDescription)
        {
            this._sectionName = sectionName;
            this._sectionDescription = sectionDescription;
        }
    }
}
