﻿namespace ConsoleApp3_20thJune2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Document document = new Resume();
            Section section1 = new ObjectiveSection();
            section1.AddSectionDetails("Objective",
                "I would like to explore my talent in a more challenging environment");
            Section section2= new EducationalSection();
            section2.AddSectionDetails("Educational Qualification",
                "B.Sc (Computer Science)");

            document.CreateSection(section1);
            document.CreateSection(section2);


            document.DisplaySectionContent();
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
