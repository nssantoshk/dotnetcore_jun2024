﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3_20thJune2024
{
    internal class Resume:Document
    {
        static int sectionindex;
        static Resume()
        {
            sectionindex = 0;
        }
        
        public override bool CreateSection(Section section)
        {
            sections[sectionindex] = section;
            sectionindex++;
            return true;
        }

        public override void DisplaySectionContent()
        {
            for(int i = 0; i < sections.Length; i++) 
            {
                Console.WriteLine("Section Details As Follows : \n{0}",
                    sections[i].ShowSectionDetails());
            }
        }
    }
}
