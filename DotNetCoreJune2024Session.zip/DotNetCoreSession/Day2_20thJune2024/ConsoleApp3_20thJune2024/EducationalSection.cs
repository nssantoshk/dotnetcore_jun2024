﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3_20thJune2024
{
    internal class EducationalSection:Section
    {
        public override void AddSectionDetails(string sectionName, string sectionDescription)
        {
            this._sectionName = sectionName;
            this._sectionDescription = sectionDescription;
        }
    }
}
