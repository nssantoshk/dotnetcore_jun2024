﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3_20thJune2024
{
    abstract internal class Document
    {
        protected Section[] sections=new Section[2];
        public abstract bool CreateSection(Section section);

        public abstract void DisplaySectionContent();
    }
}
