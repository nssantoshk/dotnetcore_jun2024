﻿using DIExample_24thJune2024.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIExample_24thJune2024.Services
{
    internal class CybageDBContext:ICybageContext
    {
        public void CloseStorage()
        {
            ////    Write a proper code to close the Database
            Console.WriteLine("Database is now closed properly. Thank you!!!");
        }

        public bool ConnectToStorage(string fileOrTableName, string filePathNameOrConnectionString)
        {
            Boolean connectionStatus = false;
            /// Write a proper code to establish connection with the database whose details are passed
            Console.WriteLine("{0} db maintained at {1} server is now opened",
                fileOrTableName, filePathNameOrConnectionString);
            return connectionStatus;
        }

        public bool SaveData(Person personElement)
        {
            Boolean transactionStatus = false;
            ////    Write a proper code that will pass this object to the respective table of the database
            Console.WriteLine("Details of {0} is now saved properly",
                personElement.PersonName);
            return transactionStatus;
        }
    }
}
