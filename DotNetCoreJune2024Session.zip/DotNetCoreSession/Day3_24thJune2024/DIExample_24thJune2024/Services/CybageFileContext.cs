﻿using DIExample_24thJune2024.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIExample_24thJune2024.Services
{
    internal class CybageFileContext : ICybageContext
    {
        public void CloseStorage()
        {
            ////    Write a proper code to close the opened file
            Console.WriteLine("File is now closed properly. Thank you!!!");
        }

        public bool ConnectToStorage(string fileOrTableName, string filePathNameOrConnectionString)
        {
            Boolean connectionStatus = false;
            /// Write a proper code to open the file whose details are passed
            Console.WriteLine("{0} file located at {1} location is now opened",
                fileOrTableName, filePathNameOrConnectionString);
            return connectionStatus;
        }

        public bool SaveData(Person personElement)
        {
            Boolean transactionStatus=false;
            ////    Write a proper code that will pass this object to the respective file
            Console.WriteLine("Details of {0} is now saved properly",
                personElement.PersonName);
            return transactionStatus;
        }
    }
}
