﻿using DIExample_24thJune2024.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIExample_24thJune2024.Services
{
    internal interface ICybageContext
    {
        /// We do not define any fields within an interface
        /// We will have methods that will help us in carrying out operations: -
        ///     1.  To open the file or database (ConnectToStorage method)
        ///     2.  To save content to the file or database (SaveData method)
        ///     3.  To close the file or database (CloseStorage method)

        Boolean ConnectToStorage(String fileOrTableName,
            String filePathNameOrConnectionString);

        Boolean SaveData(Person personElement);

        void CloseStorage();
    }
}
