﻿using DIExample_24thJune2024.Services;
using Microsoft.Extensions.Configuration;
namespace DIExample_24thJune2024
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var configurationObject =
    new ConfigurationBuilder().SetBasePath(AppContext.BaseDirectory)
    .AddJsonFile(@"D:\LND\CalendarPrograms_2024_2025\June2024\DotNetCoreSession\Day3_24thJune2024\DIExample_24thJune2024\appsettings.json",
    optional: false, reloadOnChange: true).Build();

            //Console.WriteLine("Name stored in appsettings.json file is : \t{0}",
            //    configurationObject["dbConnectivity"]);
            //Console.WriteLine("Hello, World!");

            //CybageDBContext cybageDBContext = new CybageDBContext();
            //CybageDemoApp demoApp = new CybageDemoApp(cybageDBContext);
            //Console.WriteLine(demoApp.EstablishConnection(configurationObject["tableName"], 
            //    configurationObject["dbConnectivity"]));
            //Console.WriteLine(demoApp.SaveData());
            //demoApp.Dispose();

            CybageFileContext context = new CybageFileContext();
            CybageDemoApp demoApp1=new CybageDemoApp(context);

            var connectionStatus =
                demoApp1.EstablishConnection(configurationObject["filename"],
                configurationObject["pathname"]);
            Console.WriteLine($"Connection status: {connectionStatus}");

            demoApp1.Dispose();

        }
    }
}
