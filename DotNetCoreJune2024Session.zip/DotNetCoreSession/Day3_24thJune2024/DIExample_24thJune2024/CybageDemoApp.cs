﻿using DIExample_24thJune2024.Models;
using DIExample_24thJune2024.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIExample_24thJune2024
{
    internal class CybageDemoApp:IDisposable
    {
        /// Dependency Injection can be achieved with the help of: -
        ///     1.  Constructor
        ///     2.  Property
        ///     3.  Method

        private ICybageContext? _cybageContext;

        public CybageDemoApp(ICybageContext? cybageContext) /// Applying DI using Constructor
        {
            _cybageContext = cybageContext;
        }

        public ICybageContext? CybageContext
        {
            set
            {
                _cybageContext = value;
            }
        }

        public void setContext(ICybageContext? context)
        {
            _cybageContext = context;
        }

        public void Dispose()
        {
            _cybageContext.CloseStorage();
        }

        public bool EstablishConnection(String? tbName, String? dbString)
        {
            return _cybageContext.ConnectToStorage(tbName, dbString);
        }

        public bool SaveData()
        {
            Person pItem = new Person()
            {
                PersonAge = 23,
                PersonId = 101,
                PersonName = "Jojo",
                PersonResidingCityName = "Delhi"
            };

            return _cybageContext.SaveData(pItem);
        }

    }
}
