﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DIExample_24thJune2024.Models
{
    internal class Person
    {
        public int PersonId { get; set; }
        public String? PersonName { get; set; }
        public int PersonAge { get; set; }
        public String? PersonResidingCityName { get; set; }
    }
}
