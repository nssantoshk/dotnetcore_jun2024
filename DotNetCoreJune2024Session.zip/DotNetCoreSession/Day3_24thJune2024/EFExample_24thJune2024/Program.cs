using EFExample_24thJune2024.Models;
using Microsoft.EntityFrameworkCore;

namespace EFExample_24thJune2024
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<CybageForPracticeContext>(options => options.UseSqlServer
            (options, dbContext => dbContext));
            // Add services to the container.
            builder.Services.AddRazorPages();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseStaticFiles();

            

            app.MapGet("/cybage", () => "Welcome to cybage");

            app.UseRouting();

            app.UseAuthorization();

            app.MapRazorPages();

            app.Run();
        }
    }
}
