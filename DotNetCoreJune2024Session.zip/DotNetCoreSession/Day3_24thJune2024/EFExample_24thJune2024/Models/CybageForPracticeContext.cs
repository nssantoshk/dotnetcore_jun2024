﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFExample_24thJune2024.Models;

public partial class CybageForPracticeContext : DbContext
{
    public CybageForPracticeContext()
    {
    }

    public CybageForPracticeContext(DbContextOptions<CybageForPracticeContext> options)
        : base(options)
    {
    }

    public virtual DbSet<CybageDept> CybageDepts { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=ConnectionStrings:MyDbConnection");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<CybageDept>(entity =>
        {
            entity.HasKey(e => e.DepartmentId).HasName("PK__CybageDe__B2079BED7A464063");

            entity.ToTable("CybageDept");

            entity.Property(e => e.DepartmentLocation)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.DepartmentName)
                .HasMaxLength(30)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
