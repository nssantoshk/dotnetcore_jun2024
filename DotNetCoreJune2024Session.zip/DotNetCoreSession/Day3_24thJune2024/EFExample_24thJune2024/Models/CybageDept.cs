﻿using System;
using System.Collections.Generic;

namespace EFExample_24thJune2024.Models;

public partial class CybageDept
{
    public int DepartmentId { get; set; }

    public string? DepartmentName { get; set; }

    public string? DepartmentLocation { get; set; }
}
